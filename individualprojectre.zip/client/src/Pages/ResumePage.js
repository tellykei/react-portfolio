import React from 'react';
class ResumePage extends React.Component {
    render(){
        return(
            <div>
                Resume page
            </div>

        )
    }
}
export default ResumePage;